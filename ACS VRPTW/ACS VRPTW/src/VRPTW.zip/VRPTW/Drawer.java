import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class Drawer extends JFrame {
    public int width = 800;                         // 窗体默认的宽度
    public int height = 800;                        // 窗体默认的高度
    public int board = 50;                          // 绘图区域的默认边距
    public ArrayList<Double> values = null;         // 一系列点的纵坐标（递减）


    // 构造函数
    public Drawer() {
        setSize(width, height);                     // 设置窗体宽高
        setLocationRelativeTo(null);                // 居中显示窗体
        setDefaultCloseOperation(EXIT_ON_CLOSE);    // close时关闭窗口
    }


    // 构造函数重载
    public Drawer(ArrayList<Double> values) {
        this.values = values;                       // 一系列连续点的纵坐标
        setSize(width, height);                     // 设置窗体宽高
        setLocationRelativeTo(null);                // 居中显示窗体
        setDefaultCloseOperation(EXIT_ON_CLOSE);    // close时关闭窗口
    }


    // 重写paint函数
    public void paint(Graphics g) {
        if (values == null || values.size() == 1) return;

        int n = values.size();                      // 点的总个数
        int x_begin = board;                        // 绘图区域左上角点的横坐标
        int y_begin = board;                        // 绘图区域左上角点的纵坐标
        int x_end = width - board;                  // 绘图区域右下角点的横坐标
        int y_end = height - board;                 // 绘图区域右下角点的纵坐标
        // 相邻两点横坐标间的距离
        int step = (x_end - x_begin) / (n - 1);
        // 放缩比例，将最大值最大化绘制（由于values递减，故而最大值为values.get(0)）
        double ratio = values.get(0) / (y_end - y_begin);

        // 一段段绘制直线
        for (int i = 0; i < n - 1; i++) {
            g.drawLine(x_begin + i * step, y_end - (int) (values.get(i) / ratio),
                    x_begin + (i + 1) * step, y_end - (int) (values.get(i + 1) / ratio)
            );
        }
    }
}